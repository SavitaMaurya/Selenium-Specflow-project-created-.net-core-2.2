﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Configuration;
using WebShopTestAutomation.Drivers;
using System.Threading;
using WebShopTestAutomation.PageObjects;
using System.Text.RegularExpressions;
using OpenQA.Selenium.Interactions;
using WebShopTestAutomation;
using NUnit.Framework;
using Microsoft.Extensions.Configuration;
using System.Drawing;

namespace WebShopTestAutomation
 {
    [TestFixture]
    public class SeleniumTests
    {

        //public IWebDriver OpenBrowser(string Url)
        //{
        //    //IWebDriver driver;
        //    var driver = _webDriver.Current;
        //    // driver = new InternetExplorerDriver(@"C:\Users\SU101\WebDrivers\IEDriver"); // Added from Nuget Package Manager
        //    driver = new ChromeDriver(@"C:\Users\SU101\WebDrivers\ChromeDriverLatest");
        //    driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);
        //    try
        //    {
        //        string baseUrl = ConfigurationManager.AppSettings["seleniumBaseUrl"];
        //        driver.Navigate().GoToUrl(string.Format("{0}{1}", baseUrl, Url));

        //        // To maximize
        //        driver.Manage().Window.Maximize();


        //    }
        //    catch (Exception ex)
        //    {
        //        driver.Quit();



        //    }
        //    return driver;
        //}
      
        public void ClickOnCookiesButton(WebDriver driver)
        {

            try
            {
                bool cookiesButtonVisible = false;

                HomePage objHomePage = new HomePage(driver);

                // Thread.Sleep(2000);


                List<IWebElement> lstcookiesButton = objHomePage.GetCookieButton().ToList();

                if (lstcookiesButton.Count > 0)
                {
                    IWebElement cookiesButton = lstcookiesButton[0];
                    cookiesButtonVisible = cookiesButton.Displayed;


                    if (cookiesButtonVisible)
                    {
                       
                        ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", cookiesButton);

                    }
                }


            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;

            }

        }
   
        public void ClickAndWriteOnAnywhereInWorldOption(WebDriver driver, string location)
        {
            try
            {
                //IWebElement locationElement = driver.Wait.Until(d => d.FindElement(By.ClassName("search-form-field__input-inner-wrapper")).FindElement(By.TagName("input")));
                //locationElement.Click();

                HomePage objHomePage = new HomePage(driver);
                IWebElement locationElement = objHomePage.GetLocationFilter();

                if(locationElement.Enabled)
                {
                   ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", locationElement);
                    
                }
                
                locationElement.SendKeys(location);
                                
            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;
            }

        }


   
        public void SelectlocationfromDropdown(WebDriver driver)
        {
            try
            {
                // Thread.Sleep(2000);
                HomePage objHomePage = new HomePage(driver);
                //IWebElement selectedLocation = driver.Wait.Until(d => d.FindElement(By.XPath("//a[contains(@class, 'search-guide__item-selection')]")));

                IWebElement selectedLocation = objHomePage.SelectLocationFromList();

                bool locationAvailble = selectedLocation.Displayed;
                if (locationAvailble)
                {
                    //selectedLocation.Click();
                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", selectedLocation);
                }

            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;
            }

        }

       
        public void ChooseDateFiltersForArrivalAndDeparture(WebDriver driver)
        {
            try
            {
                DateTime cdate = new DateTime();
                cdate = DateTime.Today.Date;

                var config = new ConfigurationBuilder().AddJsonFile("specflow.json").Build();

                DateTime arrivalDate = new DateTime();
                
                arrivalDate = cdate.AddDays(Convert.ToInt32(config["ArrivalInDays"]));


                DateTime deptDate = new DateTime();


                deptDate = arrivalDate.AddDays(Convert.ToInt32(config["DepartureInDays"]));

                HomePage objHomePage = new HomePage(driver);

                int Count = 0;

                List<IWebElement> lstArrivalDate = objHomePage.SelectArrivalDate().ToList();

                //if arrival day == current montrh day there will be a problem

                //var lstTempDate = lstArrivalDate.Where(obj => obj.Text == arrivalDate.Day.ToString()).ToList();

                //if (lstTempDate.Count == 3)
                //{
                //   lstArrivalDate.Remove(lstTempDate[0]);
                //}


                foreach (IWebElement element in lstArrivalDate.ToList())
                {
                    Count = 1;
                    if (arrivalDate.Day.ToString() == element.Text)
                    {

                        //element.Click();
                        ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", element);

                        break;

                    }
                    lstArrivalDate.Remove(element);

                    Count++;
                }

                //Check departure calender is open or not

                List<IWebElement> lstDepartureDate = lstArrivalDate; //Remaining dates in calender

                foreach (IWebElement element in lstDepartureDate)
                {
                    if (deptDate.Day.ToString() == element.Text)
                    {
                        //element.Click();
                        ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", element);
                        break;
                    }
                }


            }

            catch (Exception ex)
            {
                driver.Quit();
             throw ex;

            }


        }

        public void ClickOnHomePageSearchButton(WebDriver driver)
        {
            try
            {
                HomePage objHomePage = new HomePage(driver);
                // IWebElement searchElement = driver.FindElement(By.TagName("button")).FindElement(By.ClassName("frontpage-search__search-button"));
                IWebElement searchElement = objHomePage.ClickSearchButton();
                bool isenabled = searchElement.Enabled;

                if (isenabled)
                {
                    // Thread.Sleep(2000);
                    //searchElement.Click();
                    //searchElement.Submit();
                    //WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(50));
                    //wait.Until(ExpectedConditions.ElementToBeClickable(searchElement)).Click();

                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", searchElement);



                }
            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;
            }

        }

        public void CheckContentOnSearchFilterResultPage(WebDriver driver, string location)
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                //  Thread.Sleep(2000);
                string houselocation = objSearchResults.SearchResultHouse().Text;
                bool isLocationCorrect = houselocation.Contains(location);

                if (!isLocationCorrect)
                {
                    //test case fail

                    Assert.AreNotSame(1, 1);
                }
            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;
            }

        }

        public bool CheckForDuplicateHouseOnResultPage(WebDriver driver)
        {
            bool isDuplicate = false;
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                IWebElement allHouseIDs = objSearchResults.AllHouseIDs();

                // string houseIDs = (string)((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].innerHTML;", allHouseIDs);

                string houseIDs = allHouseIDs.GetAttribute("innerHTML");
                int startindex = houseIDs.IndexOf("[");
                int endindex = houseIDs.IndexOf("]");
                int length = endindex - startindex;
                houseIDs = houseIDs.Substring(startindex + 1, length);

                List<string> lstHouses = new List<string>();

                lstHouses = houseIDs.Split(',').ToList();

                if (lstHouses.Count() != lstHouses.Distinct().Count())
                {
                    isDuplicate = true;
                }

            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;
            }
            return isDuplicate;
        }


        public List<string> GetListOfHousesOnSerachResultsPage(WebDriver driver)
        {
            List<string> lstHouses = null;
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                IWebElement allHouseIDs = objSearchResults.AllHouseIDs();
                               
                string houseIDs = allHouseIDs.GetAttribute("innerHTML");
                int startindex = houseIDs.IndexOf("[");
                int endindex = houseIDs.IndexOf("]");
                int length = endindex - startindex;
                houseIDs = houseIDs.Substring(startindex + 1, length);

                lstHouses = new List<string>();

                lstHouses = houseIDs.Split(',').ToList();
                                

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
            return lstHouses;
        }


        public IWebElement ScrollDownToBottomOfSearchResultsPage(WebDriver driver)
        {
            SearchResultsPage objSearchResults = new SearchResultsPage(driver);
            IWebElement houselocation = null;
            try
            {
                List<IWebElement> lsthouselocations = objSearchResults.ScrollDownToElement().ToList();
                houselocation = lsthouselocations[lsthouselocations.Count -1];
                ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].scrollIntoView();", houselocation);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }
            return houselocation;
        }

        public void SelectHousefromtheListofHouses(WebDriver driver, IWebElement houseLocation)
        {
            try
            {
               
                ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", houseLocation);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }
        }

        //public bool VerifyHousePopUp(WebDriver driver)
        //{
        //    bool housePopUp = false;
        //    try
        //    {
        //         housePopUp = driver.Wait.Until(d => d.FindElement(By.XPath("//*[contains(@class, 'ReactModal__Content--after-open quickview__content')]"))).Displayed;


        //    }
        //    catch (Exception ex)
        //    {
        //        driver.Quit();

        //    }
        //    return housePopUp;
        //}


        //  public void ClickOnReadMoreButton(WebDriver driver)
        //{
        //    bool readMoreButtonVisible = false;
        //    try
        //    {
        //        IWebElement readMoreButton = driver.Wait.Until(d => d.FindElement(By.XPath("//*[contains(@class, 'quickview__button-container')]")));
        //        readMoreButtonVisible = readMoreButton.Displayed;


        //        if(readMoreButtonVisible)
        //        {
        //            ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", readMoreButton);
        //            //readMoreButton.Click();
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        driver.Quit();

        //    }

        //}

        public string VerifyHousePresentationPage(WebDriver driver,out string houseRentalHP)
        {
            string catalogueNumber = string.Empty;
            houseRentalHP = string.Empty;
            try
            {
                HousePresentation objPresentation = new HousePresentation(driver);

                catalogueNumber = objPresentation.GetCatalogueNumber().Text;

                catalogueNumber = Regex.Replace(catalogueNumber, @"\s", "");

                int index = catalogueNumber.LastIndexOf(":");

                catalogueNumber = catalogueNumber.Substring(index + 1);

                houseRentalHP = objPresentation.GetHouseRental().Text;
                houseRentalHP = Regex.Replace(houseRentalHP, @"\s", "");

                IWebElement bookButton = objPresentation.GetBookButton();

                ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].scrollIntoView();", bookButton);

            }

            catch (Exception ex)
            {
                driver.Quit();
             throw ex;

            }
            return catalogueNumber;
        }

        public void ClickOnBookButton(WebDriver driver)
        {

            try
            {
                bool bookButtonVisible = false;

                HousePresentation objPresentation = new HousePresentation(driver);

                // Thread.Sleep(2000);


                IWebElement bookButton = objPresentation.GetBookButton();

                bookButtonVisible = bookButton.Displayed;


                if (bookButtonVisible)
                {
                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", bookButton);

                }



            }
            catch (Exception ex)
            {
                driver.Quit();
             //throw ex;

            }

        }


        public void VerifyBookingFlowPage(WebDriver driver, string catalogueNumber, bool driverQuit)
        {

            try
            {
                BookingFlowPage objBookingFlow = new BookingFlowPage(driver);

                IWebElement propertyID = objBookingFlow.GetPropertyId();

                string expectedPageTitle = "Booking Flow";
                string pageTitle = driver.Current.Title;


                Assert.AreEqual(expectedPageTitle, pageTitle);


                string strpropertyNumber = propertyID.Text;
                strpropertyNumber = Regex.Replace(strpropertyNumber, @"\s", "");

                int index = strpropertyNumber.LastIndexOf(":");

                string PropertyNumber = strpropertyNumber.Substring(index + 1);

                Assert.AreEqual(catalogueNumber, PropertyNumber);


                if (driverQuit)
                {
                    driver.Quit();
                }


            }
            catch (Exception ex)
            {
                driver.Quit();
             //throw ex;

            }

        }

        public void FillBookingFormOnBookingNovasolSite(WebDriver driver)
        {

            try
            {

                BookingFlowPage objBookingFlow = new BookingFlowPage(driver);

                IWebElement title = objBookingFlow.Title();


                bool titleDisplayed = title.Displayed;

                //Thread.Sleep(2000);

                if (titleDisplayed)
                {
                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", title);

                }


                title.SendKeys(Keys.Down);
                title.SendKeys(Keys.Enter);

                objBookingFlow.FirstName().SendKeys(ApplicationConstants.firstName.ToString());
                objBookingFlow.LastName().SendKeys(ApplicationConstants.lastName.ToString());
                objBookingFlow.Email().SendKeys(ApplicationConstants.email.ToString());
                objBookingFlow.VerifyEmail().SendKeys(ApplicationConstants.email.ToString());
                objBookingFlow.Phone().SendKeys(ApplicationConstants.phone.ToString());
                objBookingFlow.AdditionalPhone().SendKeys(ApplicationConstants.additionalPhone.ToString());
                objBookingFlow.Address().SendKeys(ApplicationConstants.address.ToString());
                objBookingFlow.AdditionalAddress().SendKeys(ApplicationConstants.additionalAddress.ToString());
                objBookingFlow.HouseNumber().SendKeys(ApplicationConstants.houseNumber.ToString());
                objBookingFlow.Floor().SendKeys(ApplicationConstants.floor.ToString());
                objBookingFlow.PostalCode().SendKeys(ApplicationConstants.postalCode.ToString());
                objBookingFlow.City().SendKeys(ApplicationConstants.city.ToString());

                IWebElement country = objBookingFlow.Country();

                country.SendKeys(ApplicationConstants.country.ToString());
                //Thread.Sleep(2000);
                country.SendKeys(Keys.Enter);

                //Thread.Sleep(2000);



                IWebElement acceptTermCheckbox = objBookingFlow.AcceptTerms();

                bool acceptTermsEnabled = acceptTermCheckbox.Enabled;


                if (acceptTermsEnabled)
                {
                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", acceptTermCheckbox);

                }


                if (objBookingFlow.CountryDropDown().Count > 0)
                {
                    country.SendKeys(Keys.Enter);
                    //Thread.Sleep(1000);
                }

                IWebElement paymentOption = objBookingFlow.PaymentOption();

                bool paymentOptionEnabled = paymentOption.Enabled;


                ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].scrollIntoView();", paymentOption);


                if (paymentOptionEnabled)
                {
                    //Thread.Sleep(4000);
                    //((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", paymentOption);

                    Actions action = new Actions(driver.Current);
                    action.MoveToElement(paymentOption);

                    action.Click();

                    action.SendKeys(Keys.Enter);
                    action.Build();
                    action.Perform();


                    // Thread.Sleep(3000);
                    //paymentOption.SendKeys(Keys.Enter);

                }
                // Thread.Sleep(1000);




            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;

            }
        }
        public void ClickOnRequestBookingButton(WebDriver driver)
        {

            bool requestButtonVisible = false;
            try
            {


                BookingFlowPage objBookingFlow = new BookingFlowPage(driver);

                // Thread.Sleep(2000);
                IWebElement requestBookButton = objBookingFlow.BookingRequestButton();

                requestButtonVisible = requestBookButton.Displayed;


                if (requestButtonVisible)
                {
                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", requestBookButton);

                }



            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;

            }

        }

       

       

     
        public int GetHouseCountOnSearchResultPage(WebDriver driver)
        {
            int HouseCount = 0;
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                
                HouseCount = objSearchResults.ResultHouseCount();


            }
            catch (Exception ex)
            {
                driver.Quit();
             throw ex;

            }
            return HouseCount;

        }

        public void ClickThemePageLink(WebDriver driver)
        {
            try
            {
                HomePage objHomePage = new HomePage(driver);
             
               IWebElement themeElement = objHomePage.GetThemePageLink();
           
              ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", themeElement);
                
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }

        }

       

        public void VerifyDogFriendlyThemePage(WebDriver driver)
        {
            
            try
            {

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }
           
        }
  

        public void RemoveHouseFromFavorites(WebDriver driver)
        {

            try
            {
            //to do
            

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }

        }

        public void RemoveDishwasherFilter(WebDriver driver)
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                IWebElement facilitiesClose = objSearchResults.GetDiswasherFacility();
                bool facilitiesCloseEnabled = facilitiesClose.Enabled;

                if (facilitiesCloseEnabled)
                {
                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", facilitiesClose);

                }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }
        }
      

        public void CloseFacilityFilter(WebDriver driver)
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                IWebElement facilitiesClose = objSearchResults.GetCloseFacilities();
                bool facilitiesCloseEnabled = facilitiesClose.Enabled;

                if (facilitiesCloseEnabled)
                {
                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", facilitiesClose);

                }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }
        }

        public IWebElement GetPriceSlider(WebDriver driver, out int sliderWidth, bool toLow)
        {
            IWebElement priceSliderElement = null;
            sliderWidth = 0;
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                IWebElement PriceFilter = objSearchResults.GetPriceFilter();
                bool PriceFilterrEnabled = PriceFilter.Enabled;

                if (PriceFilterrEnabled)
                {
                    ((IJavaScriptExecutor)driver.Current).ExecuteScript("arguments[0].click();", PriceFilter);

                }

                IWebElement priceSlider = objSearchResults.GetPriceSlider();
                Size sliderSize = priceSlider.Size;

                sliderWidth = sliderSize.Width;

                 priceSliderElement = objSearchResults.GetPriceSliderElement(toLow);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;

            }
            return priceSliderElement;
        }

    }
}
