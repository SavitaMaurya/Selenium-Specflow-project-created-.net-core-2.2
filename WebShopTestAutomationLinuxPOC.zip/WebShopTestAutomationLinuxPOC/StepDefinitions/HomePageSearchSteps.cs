﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using WebShopTestAutomation.Drivers;
using System.Configuration;
using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Drawing;
using WebShopTestAutomation.PageObjects;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Interactions;
using System.Threading;
//using System.Windows;

namespace WebShopTestAutomation
{
    [Binding]
    public class CheckTheSearchFunctionalityToFindHolidayHomesSteps
    {
        private readonly WebDriver _webDriver;

        public CheckTheSearchFunctionalityToFindHolidayHomesSteps(WebDriver webDriver)
        {
            _webDriver = webDriver;
        }

        //IWebDriver driver;
        string location = string.Empty;

        SeleniumTests obj = new SeleniumTests();


        string catalogueNumber = string.Empty;
        int HouseCountOrig = 0;
        int HouseCountFinal = 0;

        string rentalPriceSearchPage = string.Empty;


        string rentalPriceHP = string.Empty;


        [Given(@"I am on Novasol website(.*)")]
        public void GivenIAmOnNovasolWebsite(string url)
        {
            var driver = _webDriver.Current;
            try
            {
                url = Regex.Replace(url, @"\s", "");

                driver.Manage().Window.Maximize();

                //Size initial_size = driver.Manage().Window.Size;
                //int height = initial_size.Height;
                //int width = initial_size.Width;
                //int new_height = (int)Math.Round(height * (0.75));
                //driver.Manage().Window.Size = new Size(width, new_height);  

                driver.Manage().Window.Maximize();

                var config = new ConfigurationBuilder().AddJsonFile("specflow.json").Build();

                string baseUrl = config["seleniumBaseUrl"];

                //  string baseUrl = ConfigurationManager.AppSettings["seleniumBaseUrl"];
                driver.Navigate().GoToUrl(string.Format("{0}{1}", baseUrl, url));

            }
            catch (Exception ex)
            {
                driver.Quit();
                Console.WriteLine(ex);
            }
        }
        [Given(@"I close the cookies button if pops up")]
        public void GivenICloseTheCookiesButtonIfPopsUp()
        {
            try
            {
                obj.ClickOnCookiesButton(_webDriver);

            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }

        [Given(@"I clicked on Anywhere in Europe option and started writing location name (.*)")]
        public void GivenIClickedOnAnywhereInEuropeOptionAndStartedWritingLocationName(string p0)
        {
            try
            {
                obj.ClickAndWriteOnAnywhereInWorldOption(_webDriver, p0);
                location = p0;
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);
            }
        }

        [Then(@"I clicked on Anywhere in Europe option and started changing location name (.*)")]
        public void ThenIClickedOnAnywhereInEuropeOptionAndStartedChangingLocationName(string p1)
        {
            try
            {
                HomePage objHomePage = new HomePage(_webDriver);
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);

                IWebElement DesinationClose = objHomePage.GetDesinationClose();

                if (DesinationClose.Enabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", DesinationClose);

                }
                objSearchResults.ResultHouseCount(); // JUST SO THAT PAGE LOADS COMPLETELY BEFORE CHANGING LOCATION

                obj.ClickAndWriteOnAnywhereInWorldOption(_webDriver, p1);
                location = p1;
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);
            }
        }

        [Then(@"location should be auto populate which I can select")]
        public void ThenLocationShouldBeAutoPopulateWhichICanSelect()
        {
            try
            {
                obj.SelectlocationfromDropdown(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);
            }

        }


        [When(@"I choose date filters for Arrival and Departure")]
        public void WhenIChooseDateFiltersForArrivalAndDeparture()
        {
            try
            {
                obj.ChooseDateFiltersForArrivalAndDeparture(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();

                Console.WriteLine(ex);


            }
        }


        [When(@"I clicked on Search option")]
        public void WhenIClickedOnSearchOption()
        {
            try
            {
                obj.ClickOnHomePageSearchButton(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }


        [Then(@"Holiday homes should populate")]
        public void ThenHolidayHomesShouldPopulate()
        {
            try
            {
                obj.CheckContentOnSearchFilterResultPage(_webDriver, location);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }


        [Then(@"there should be no duplicate house on page")]
        public void ThenThereShouldBeNoDuplicateHouseOnPage()
        {
            try
            {
                bool duplicateHouse = obj.CheckForDuplicateHouseOnResultPage(_webDriver);

                if (duplicateHouse)
                {
                    Assert.Fail();

                }
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }



        [Then(@"I scrolled down till the last house available on the page and Click on Go to Property button")]
        public void ThenIScrolledDownTillTheLastHouseAvailableOnThePageAndClickOnGoToPropertyButton()
        {

            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);

                IWebElement houselocation = obj.ScrollDownToBottomOfSearchResultsPage(_webDriver);

                rentalPriceSearchPage = objSearchResults.GetRentalPrice();

                obj.SelectHousefromtheListofHouses(_webDriver, houselocation);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }

        }


        [Then(@"House presentation page should open and page should look correct")]
        public void ThenHousePresentationPageShouldOpenAndPageShouldLookCorrect()
        {

            try
            {
                catalogueNumber = obj.VerifyHousePresentationPage(_webDriver, out rentalPriceHP);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }

        }

        [Then(@"House rental price should be same on Search Result and House presentation page")]
        public void ThenHouseRentalPriceShouldBeSameOnSearchResultAndHousePresentationPage()
        {
            try
            {
                Assert.AreEqual(rentalPriceSearchPage, rentalPriceHP);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }


        string rentalPriceBookingPage = string.Empty;

        [Then(@"House rental price should be same on House presentation page and Booking Flow page")]
        public void ThenHouseRentalPriceShouldBeSameOnHousePresentationPageAndBookingFlowPage()
        {
            try
            {
                BookingFlowPage objBookingFlow = new BookingFlowPage(_webDriver);
                rentalPriceBookingPage = objBookingFlow.GetHouseRental().Text;
                rentalPriceBookingPage = Regex.Replace(rentalPriceBookingPage, @"\s", "");

                int startindex = rentalPriceBookingPage.IndexOf(",");
                rentalPriceBookingPage = rentalPriceBookingPage.Remove(startindex, 3);

                Assert.AreEqual(rentalPriceHP, rentalPriceBookingPage);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }


        [When(@"I clicked on Book button")]
        public void WhenIClickedOnBookButton()
        {
            try
            {
                obj.ClickOnBookButton(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }

        [Then(@"I should be directed to Novasol Booking page (.*)")]
        public void ThenIShouldBeDirectedToNovasolBookingPage(int driverQuit)
        {
            try
            {
                obj.VerifyBookingFlowPage(_webDriver, catalogueNumber, Convert.ToBoolean(driverQuit));
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }
        [Then(@"I check the house count available")]
        public void ThenICheckTheHouseCountAvailable()
        {
            try
            {
                HouseCountFinal = obj.GetHouseCountOnSearchResultPage(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);
            }
        }
        [When(@"I check the house count available")]
        public void WhenICheckTheHouseCountAvailable()
        {

            try
            {
                HouseCountFinal = obj.GetHouseCountOnSearchResultPage(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);
            }
        }

        [Then(@"save the result count temporarily")]
        public void ThenSaveTheResultCountTemporarily()
        {
            try
            {
                HouseCountOrig = HouseCountFinal;
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);
            }
        }

        //[Then(@"House count on both sites should match")]
        //public void ThenHouseCountOnBothSitesShouldMatch()
        //{
        //    try
        //    {
        //        Assert.AreEqual(HouseCount, HouseCountDk);
        //        _webDriver.Quit();
        //    }

        //    catch (Exception ex)
        //    {
        //        _webDriver.Quit();
        //        //Console.WriteLine(ex);
        //    }

        //}
        [When(@"I choose date filters for Arrival and Departure in a future")]
        public void WhenIChooseDateFiltersForArrivalAndDepartureInAFuture()
        {

            try
            {
                HousePresentation objHousePresentation = new HousePresentation(_webDriver);
                DateTime cdate = new DateTime();
            cdate = DateTime.Today.Date;

               

                var config = new ConfigurationBuilder().AddJsonFile("specflow.json").Build();

            DateTime arrivalDate = new DateTime();

            arrivalDate = cdate.AddDays(Convert.ToInt32(config["ArrivalInDays"]));

            DateTime deptDate = new DateTime();

            deptDate = arrivalDate.AddDays(Convert.ToInt32(config["DepartureInDays"]));

            HomePage objHomePage = new HomePage(_webDriver);

            DateTime newArrivalDate = new DateTime();
            newArrivalDate = arrivalDate.AddMonths(Convert.ToInt32(config["TotalFutureMonths"]));
            DateTime newDeptDate = new DateTime();
            newDeptDate = deptDate.AddMonths(Convert.ToInt32(config["TotalFutureMonths"]));

            int Count = 0;

                //Click the calender arrow buttons 

                IWebElement calenderArrow = objHousePresentation.GetCalenderRightArrow();

                if (calenderArrow.Enabled)
                {
                    for (int i = 0; i < Convert.ToInt32(config["TotalFutureMonths"]); i++)
                    {
                        ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", calenderArrow);
                    }
                }

                //Click the calender arrow buttons 

                List<IWebElement> lstArrivalDate = objHomePage.SelectArrivalDate().ToList();
                              

                foreach (IWebElement element in lstArrivalDate.ToList())
                {
                    Count = 1;
                    if (newArrivalDate.Day.ToString() == element.Text)
                    {

                        //element.Click();
                        ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", element);

                        break;

                    }
                    lstArrivalDate.Remove(element);

                    Count++;
                }

                //Check departure calender is open or not

                List<IWebElement> lstDepartureDate = lstArrivalDate; //Remaining dates in calender

                foreach (IWebElement element in lstDepartureDate)
                {
                    if (newDeptDate.Day.ToString() == element.Text)
                    {
                        //element.Click();
                        ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", element);
                        break;
                    }
                }
            }

            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }
        }

        [When(@"Choose Two adults,two children and a pet from Guest Picker")]
        public void WhenChooseTwoAdultsTwoChildrenAndAPetFromGuestPicker()
        {
            try
            {
                SearchResultsPage objSearchResultsPage = new SearchResultsPage(_webDriver);
                IWebElement GuestPicker = objSearchResultsPage.GetGuestPickerDropdown();

               // Actions action = new Actions(_webDriver.Current);

                bool isenabled = GuestPicker.Enabled;

                //if (isenabled)
                //{
                //    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", GuestPicker);

                //}

                if (isenabled)
                {
                    //Select 2 children
                    List<IWebElement> lstGuestDropdwn = objSearchResultsPage.SelectFromGuestPickerDropdown().ToList();

                    IWebElement selectChildren = lstGuestDropdwn[1];
                    bool selectChildrenEnabled = selectChildren.Enabled;
                    bool selectChildrenDispalyed = selectChildren.Displayed;

                    if (selectChildrenDispalyed && selectChildrenEnabled)
                    {
                         ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", selectChildren);
                       // action.MoveToElement(selectChildren).Click();
                        //action.SendKeys("2").Build().Perform();
                       //selectChildren.SendKeys("02");
                       
                        ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", selectChildren);
                       
                    }
                  
                    //Select 1 Pet

                    IWebElement selectPets = lstGuestDropdwn[2];
                    bool selectPetsEnabled = selectPets.Enabled;
                    if (selectPetsEnabled)
                    {
                        ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", selectPets);
                       // selectPets.SendKeys("01");
                        Thread.Sleep(1000);

                    }
                }

                IWebElement GuestPickerClose = objSearchResultsPage.GetCloseGuestPicker();


                if (GuestPickerClose.Enabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", GuestPickerClose);

                }

            }

            catch (Exception ex)
            {
                _webDriver.Quit();
                //Console.WriteLine(ex);
            }


        }

        [Then(@"I filtered the houses by selecting on Dishwasher")]
        public void ThenIFilteredTheHousesBySelectingOnDishwasher()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);
                IWebElement facilitiesOption = objSearchResults.GetFacilitiesOption();
                bool facilitiesOptionEnabled = facilitiesOption.Enabled;

                if (facilitiesOptionEnabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", facilitiesOption);

                }

                IWebElement dishwasherOption = objSearchResults.GetDiswasherFacility();
                bool dishwasherOptionEnabled = dishwasherOption.Enabled;

                if (dishwasherOptionEnabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", dishwasherOption);

                }

                obj.CloseFacilityFilter(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }

        }
        [Then(@"House count should decrease or remain same")]
        public void ThenHouseCountShouldDecreaseOrRemainSame()
        {
            try
            {
                if (HouseCountOrig < HouseCountFinal)
                {
                    Assert.Fail();
                }
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }

        [Then(@"House count should increase or remain same")]
        public void ThenHouseCountShouldIncreaseOrRemainSame()
        {
            try
            {
                if (HouseCountOrig > HouseCountFinal)
                {
                    Assert.Fail();
                }
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }

        [Then(@"House count should increase")]
        public void ThenHouseCountShouldIncrease()
        {
            try
            {
                if (HouseCountOrig < HouseCountFinal)
                {
                    Assert.Fail();
                }
                _webDriver.Quit();
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }

        [Then(@"House count should decrease")]
        public void ThenHouseCountShouldDecrease()
        {
            try
            {
                if (HouseCountOrig > HouseCountFinal)
                {
                    // Assert.Fail();
                }
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }


        [Then(@"Change the number of Adults to (.*)")]
        public void ThenChangeTheNumberOfAdultsTo(int p0)
        {
            try
            {
                SearchResultsPage objSearchResultsPage = new SearchResultsPage(_webDriver);
                IWebElement GuestPicker = objSearchResultsPage.GetGuestPickerDropdown();

                bool isenabled = GuestPicker.Enabled;

                if (isenabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", GuestPicker);

                }
                List<IWebElement> lstGuestDropdwn = objSearchResultsPage.SelectFromGuestPickerDropdown().ToList();

                IWebElement selectAdults = lstGuestDropdwn[0];
                bool selectAdultsEnabled = selectAdults.Enabled;

                if (selectAdultsEnabled)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", selectAdults);
                    }
                    // selectAdults.SendKeys("1"); //as it will become 12 since added in front of 2
                    Thread.Sleep(1000);
                }
                IWebElement GuestPickerClose = objSearchResultsPage.GetCloseGuestPicker();


                if (GuestPickerClose.Enabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", GuestPickerClose);

                }

            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }


        [Then(@"I check dishwasher filter is still applied")]
        public void ThenICheckDishwasherFilterIsStillApplied()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);
                IWebElement facilitiesOption = objSearchResults.GetFacilitiesOption();
                bool facilitiesOptionEnabled = facilitiesOption.Enabled;

                if (facilitiesOptionEnabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", facilitiesOption);

                }

                IWebElement dishwasherOption = objSearchResults.GetDiswasherFacility();
                bool dishwasherOptionEnabled = dishwasherOption.Enabled;

                if (!dishwasherOptionEnabled)
                {
                    Assert.Fail();
                }
                obj.CloseFacilityFilter(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }

        [Then(@"I remove the dishwasher filter")]
        public void ThenIRemoveTheDishwasherFilter()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);
                IWebElement facilitiesOption = objSearchResults.GetFacilitiesOption();
                bool facilitiesOptionEnabled = facilitiesOption.Enabled;

                if (facilitiesOptionEnabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", facilitiesOption);

                }
                obj.RemoveDishwasherFilter(_webDriver);
                obj.CloseFacilityFilter(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }


        [When(@"I low the price slider")]
        public void WhenILowThePriceSlider()
        {
            try
            {

                IWebElement priceSliderElement = obj.GetPriceSlider(_webDriver, out int SliderWidth, false);


                Actions builder = new Actions(_webDriver.Current);

                int offsetWidth = SliderWidth / 4;

                builder.DragAndDropToOffset(priceSliderElement, -offsetWidth, 0).Build().Perform();


                obj.CloseFacilityFilter(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }

        }

        [When(@"I up the price slider")]
        public void WhenIUpThePriceSlider()
        {
            try
            {

                IWebElement priceSliderElement = obj.GetPriceSlider(_webDriver, out int SliderWidth, false);

                Actions builder = new Actions(_webDriver.Current);
                int offsetWidth = SliderWidth / 4;

                builder.DragAndDropToOffset(priceSliderElement, offsetWidth, 0).Build().Perform();

                obj.CloseFacilityFilter(_webDriver);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }

        [When(@"I sort the houses on basis of lowest price")]
        public void WhenISortTheHousesOnBasisOfLowestPrice()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);
                IWebElement SortingFilter = objSearchResults.GetSortingFilter();
                Actions builder = new Actions(_webDriver.Current);

                //builder.MoveToElement(SortingFilter).Click();

                if (SortingFilter.Enabled)
                {
                    ((IJavaScriptExecutor)_webDriver.Current).ExecuteScript("arguments[0].click();", SortingFilter);

                    objSearchResults.WaitTillSortingFilterOpen();
                  

                    builder.SendKeys(Keys.ArrowDown);
                    builder.SendKeys(Keys.ArrowDown);
                    builder.SendKeys(Keys.ArrowDown);
                    builder.SendKeys(Keys.Enter);
                }



            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }

        [Then(@"I check the houses are sorted correctly")]
        public void ThenICheckTheHousesAreSortedCorrectly()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);
                List<decimal> lstHousePrice = objSearchResults.PriceOfAllHousesOnPage();
                var expectedList = lstHousePrice.OrderBy(x => x);
                Assert.IsTrue(expectedList.SequenceEqual(lstHousePrice));
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }


        string SelectedPriceRange = string.Empty;
        List<string> lstHousesSR = null;

        [When(@"I saved the Selected Filters and House list temporarily")]
        public void WhenISavedTheSelectedFiltersAndHouseListTemporarily()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);
                IWebElement SelectedFilter = objSearchResults.GetSelectedFilter();

                SelectedPriceRange = SelectedFilter.Text;

                lstHousesSR = obj.GetListOfHousesOnSerachResultsPage(_webDriver);


            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }


        [When(@"I click on the browser back button")]
        public void WhenIClickOnTheBrowserBackButton()
        {
            try
            {
                _webDriver.Current.Navigate().Back();
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }
        string SelectedPriceActual = string.Empty;
        List<string> lstHouseActual = null;


        [Then(@"I check the price slider and sorting method is remembered")]
        public void ThenICheckThePriceSliderAndSortingMethodIsRemembered()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(_webDriver);
                IWebElement SelectedFilter = objSearchResults.GetSelectedFilter();

                SelectedPriceActual = SelectedFilter.Text;

                Assert.AreEqual(SelectedPriceRange, SelectedPriceActual);

            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }

        [Then(@"The number of houses are same as before moving to HP page")]
        public void ThenTheNumberOfHousesAreSameAsBeforeMovingToHPPage()
        {
            try
            {

                lstHouseActual = obj.GetListOfHousesOnSerachResultsPage(_webDriver);
                Assert.AreEqual(lstHousesSR, lstHouseActual);
            }
            catch (Exception ex)
            {
                _webDriver.Quit();
                Console.WriteLine(ex);

            }
        }



    }
}
