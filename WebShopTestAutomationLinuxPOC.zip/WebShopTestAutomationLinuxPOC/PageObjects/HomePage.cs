﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class HomePage
    {

        private WebDriverWait wait;
        //private readonly Actions actions;
        //private IJavaScriptExecutor js;
        WebDriver webDriver;
        public HomePage(WebDriver webDriver)
        {

            this.webDriver = webDriver;

            wait = new WebDriverWait(webDriver.Current, TimeSpan.FromSeconds(60));

        }

        public IList<IWebElement> GetCookieButton()
        {
            IList<IWebElement> CookieButton = webDriver.Current.FindElements(By.XPath("//button[contains(@class, 'cc_btn_accept_all')]"));
            return CookieButton;

        }


        public IWebElement GetLocationFilter()
        {
            IWebElement LocationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form-field__input-inner-wrapper')]/input")));
            return LocationFilter;

        }

        public IWebElement GetDesinationClose()
        {
            IWebElement LocationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form__destination-item-close')]")));
            return LocationFilter;

        }
        public IWebElement SelectLocationFromList()
        {
            IWebElement SelectLocation = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//a[contains(@class, 'search-guide__item-selection')]")));
            return SelectLocation;
        }

        public IList<IWebElement> SelectArrivalDate()
        {
            IWebElement ArrivalDate = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]")));

            IList<IWebElement> lstArrivalDate = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]"));

            return lstArrivalDate;
        }

        public IWebElement ClickSearchButton()
        {
            IWebElement SearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//button[contains(@class, 'frontpage-search__search-button')]")));
            return SearchButton;
        }

        public IWebElement GetThemePageLink()
        {
            IWebElement SearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//nav[contains(@class, 'site-header__nav')]//li[contains(@class, 'themepicker')]//a")));
            return SearchButton;
        }

       
    }
  }
