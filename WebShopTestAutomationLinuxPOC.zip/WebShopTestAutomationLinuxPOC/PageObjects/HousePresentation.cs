﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
   public class HousePresentation
    {
        //public HousePresentationObjects(WebDriver _webDriver)
        //{
        //    PageFactory.InitElements(_webDriver.Current, this);
        //}


        private WebDriverWait wait;
        //private readonly Actions actions;
        //private IJavaScriptExecutor js;
        WebDriver webDriver;
        public HousePresentation(WebDriver webDriver)
        {

            this.webDriver = webDriver;

            wait = new WebDriverWait(webDriver.Current, TimeSpan.FromSeconds(60));

        }

        //[FindsBy(How = How.XPath, Using = "//*[contains(@class, 'booking-button--valid')]")]
        //protected IWebElement BookButton { get; set; }


        //[FindsBy(How = How.XPath, Using = "//*[contains(@class, 'rental-overview__catalogue-number')]")]
        //protected IWebElement CatalogueNumber { get; set; }


        public IWebElement GetBookButton()
        {
            IWebElement BookButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'booking-button')]")));
            return BookButton;
        }
        public IWebElement GetCatalogueNumber()
        {
            IWebElement CatalogueNumber = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'rental-overview__catalogue-number')]")));
            return CatalogueNumber;
        }


        public IWebElement GetHouseRental()
        {
            IWebElement HouseRental = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//span[contains(@class, 'pricebox__wrap-price--price')]/span")));
            return HouseRental;
        }

        public IList<IWebElement> GetHPRightImageArrow()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//button[contains(@class, 'flickity-button')][@aria-label ='Next']")));
            IList<IWebElement> HPRightImageArrow = webDriver.Current.FindElements(By.XPath("//button[contains(@class, 'flickity-button')][@aria-label ='Next']/*[name()='svg']"));
            return HPRightImageArrow;
        }

        public IWebElement IsRightImageArrowEnd()
        {
            IWebElement RightImageArrowEnd = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//button[contains(@class, 'flickity-button')][@aria-label ='Next']")));
            return RightImageArrowEnd;
        }

        public IList<IWebElement> GetHPLeftImageArrow()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//button[contains(@class, 'flickity-button')][@aria-label ='Previous']")));
            IList<IWebElement> HPLeftImageArrow = webDriver.Current.FindElements(By.XPath("//button[contains(@class, 'flickity-button')][@aria-label ='Previous']/*[name()='svg']"));
            return HPLeftImageArrow;
        }
        public IWebElement IsLeftImageArrowEnd()
        {
            IWebElement LeftImageArrowEnd = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//button[contains(@class, 'flickity-button')][@aria-label ='Previous']")));
            return LeftImageArrowEnd;
        }
        public IWebElement GetFloorPlan()
        {
            IWebElement HouseRental = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//span[contains(@class, 'rental-assets-button--floorplan')]")));
            return HouseRental;
        }

        public IWebElement GetArrivalCalender()
        {
            //IWebElement ArrivalCalender = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'DateRangePickerInput')]//input[@id ='startDate']")));
            IWebElement ArrivalCalender = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'DateRangePickerInput')]//div[contains(@class, 'DateInput')]")));
            return ArrivalCalender;
        }

        public IWebElement GetCalenderRightArrow()
        {
            IWebElement ArrivalCalender = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'DayPickerNavigation')]//button[contains(@class, 'DayPickerNavigation__next')]")));
            return ArrivalCalender;
        }


        public IList<IWebElement> SelectArrivalDate()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]")));

            IList<IWebElement> lstArrivalDate = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]"));

            return lstArrivalDate;
        }

        public IWebElement GetPersonButtonOfCalender()
        {
            IWebElement PersonButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'guestpicker__button')]//button[contains(@class, 'button')]")));
            return PersonButton;
        }
        public IWebElement GetAboutPropertySubMenu()
        {
            IWebElement AboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'rental-submenu__wrapper')]//a[contains(@href, '#about-house')]")));
            return AboutProperty;
        }

        public IWebElement CheckOnAboutProperty()
        {
            IWebElement OnAboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-facilities')]")));
            return OnAboutProperty;
        }
        public IWebElement CheckFloorPlanDisplayed()
        {
            IWebElement OnAboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-assets__cell--floorplan')]")));
            return OnAboutProperty;
        }

        public IWebElement GetCloseFloorPlanIcon()
        {
            IWebElement OnAboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//img[contains(@class, 'rental-lightbox__button--close')]")));
            return OnAboutProperty;
        }

        public IList<IWebElement> GetNearByMenu()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'house-map-interest__list')]//div[contains(@class, 'house-map-interest__interest-point')]")));
            IList<IWebElement> NearByMenu = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'house-map-interest__list')]//div[contains(@class, 'house-map-interest__interest-point')]/input"));
            return NearByMenu;
        }

        public IWebElement CheckAirportShownOnMap()
        {
            IWebElement OnAirport = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-map')]//div[contains(@class, 'house-map-interest__marker')][contains(@title, 'Airport')]")));
            return OnAirport;
        }

        public IWebElement CheckSimilarHousesOnPage()
        {
            IWebElement OnAboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'similar-houses')]//h3")));
            return OnAboutProperty;
        }
        public IWebElement GetSocialSharingIcon()
        {
            IWebElement SocialSharing = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//span[contains(@class, 'rental-assets-button--share')]/i")));
            return SocialSharing;
        }

        public IWebElement GetSocialSharingOverlay()
        {
            IWebElement SocialSharingOverlay = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'rental-share group')]")));
            return SocialSharingOverlay;
        }

        public IWebElement GetCloseSocialSharingOverlay()
        {
            IWebElement CloseSocialSharingOverlay = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'rental-share group')]/a[contains(@class, 'rental-share__close')]")));
            return CloseSocialSharingOverlay;
        }

    }
}
