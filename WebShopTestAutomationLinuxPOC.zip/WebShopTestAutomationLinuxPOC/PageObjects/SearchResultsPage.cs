﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;
using System.Text.RegularExpressions;

namespace WebShopTestAutomation.PageObjects
{
    public class SearchResultsPage
    {
              
        private WebDriverWait wait;
        //private readonly Actions actions;
        //private IJavaScriptExecutor js;
        WebDriver webDriver;
        public SearchResultsPage(WebDriver webDriver)
        {

            this.webDriver = webDriver;

            wait = new WebDriverWait(webDriver.Current, TimeSpan.FromSeconds(60));
        }

        //[FindsBy(How = How.XPath, Using = "//*[contains(@class, 'house-card__body')]")]
        //protected IWebElement ResultHouse { get; set; }

        //[FindsBy(How = How.XPath, Using = "//*[contains(@class, 'search-results__item')][last()]//div[contains(@class, 'house-card__action')]/a[contains(@class, 'house-card__button')]")]
        //protected IList<IWebElement> ScrollDown { get; set; }

        public IWebElement SearchResultHouse()
        {
            IWebElement ResultHouse = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'house-card__body')]")));
            return ResultHouse;
        }
        public IWebElement AllHouseIDs()
        {
            IWebElement AllHouseIDs = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//script[contains(text(),'content_ids')][last()]")));
            return AllHouseIDs;
        }

        public int ResultHouseCount()
        {
            int houseCount = 0;
            List<IWebElement> CheckHousesAvailable = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'search-results__no-results')]")).ToList();
            if(CheckHousesAvailable.Count > 0)
            {
                houseCount = 0;
            }
            else
            { 
            IWebElement ResultHouseTitle = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'search-results__title')]//span[contains(@class, 'search-results__count')]")));
             houseCount = Convert.ToInt32(ResultHouseTitle.Text);
            }
            return houseCount;
        }

        public IList<IWebElement> ScrollDownToElement()
        {
            IWebElement ScrollDown = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//*[contains(@class, 'search-results__item')]//div[contains(@class, 'house-card__action')]")));
            IList<IWebElement> lstScrollDown = webDriver.Current.FindElements(By.XPath("//*[contains(@class, 'search-results__item')][last()]//div[contains(@class, 'house-card__action')]/a[contains(@class, 'house-card__button')]"));
            return lstScrollDown;
        }
        public string GetRentalPrice()
        {
            
                //string houseRental = houselocation.FindElement(By.XPath("//div[contains(@class, 'house-card__price')]/span")).Text;
                List<IWebElement> lstRentalHouses = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'house-card__price')]/span")).ToList();
            IWebElement lastHouseRental = lstRentalHouses[lstRentalHouses.Count - 1];

            string houseRental = lastHouseRental.Text;

            houseRental = Regex.Replace(houseRental, @"\s", "");
            return houseRental;

        }

        public List<decimal> PriceOfAllHousesOnPage()
        {
            List<decimal> LstHousePrice = null;
            try
            {
              
            List<IWebElement> lstRentalHouses = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'house-card__price')]/span")).ToList();

            foreach(IWebElement housePrice in lstRentalHouses)
            {
                string houseRental = housePrice.Text;

                houseRental = Regex.Replace(houseRental, @"\s", "");
                    houseRental = houseRental.Substring(0, houseRental.Length - 3);
                   
                    decimal homeRental =  Convert.ToDecimal(houseRental);

                    LstHousePrice.Add(homeRental);
                
            }
            }
            catch (Exception ex)
            {

                throw ex;

            }
            return LstHousePrice;

                       
        }

        public List<IWebElement> GetSearchResultHouses()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__items')]//div[@class ='house-card']")));
            List<IWebElement> SearchResultHouse = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'search-results__items')]//div[@class ='house-card']")).ToList();
            return SearchResultHouse;
        }
        public List<IWebElement> FavoriteIcon()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//i[contains(@class, 'favourite-box__icon')]")));
            List<IWebElement> lstHouses = webDriver.Current.FindElements(By.XPath("//i[contains(@class, 'favourite-box__icon')]")).ToList();

            return lstHouses;
        }

        public IWebElement FavoriteLink()
        {
            IWebElement favoriteLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//li[contains(@class, 'header-favorites-link--has-favorites')]")));
            return favoriteLink;

        }

        public IWebElement GetGuestPickerDropdown()
        {
            IWebElement GuestPicker = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'search-form-field--guests')]//input[@type = 'button']")));
            return GuestPicker;
        }
        IList<IWebElement> lstGuestDropdwn = null;
        public IList<IWebElement> SelectFromGuestPickerDropdown()
        {
            IWebElement GuestPicker = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'guestpicker__dropdown')]//div[contains(@class, 'guestpicker__incrementbutton')]/button")));
           //lstGuestDropdwn = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'guestpicker__dropdown')]//div[contains(@class, 'guestpicker__numberinput')]/input"));
            lstGuestDropdwn = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'guestpicker__dropdown')]//div[contains(@class, 'guestpicker__incrementbutton')]"));
            return lstGuestDropdwn;
        }
        public IWebElement GetChildrenIncrementButton()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(lstGuestDropdwn[1]));
            IWebElement ChildrenIncrementButton = lstGuestDropdwn[1];
            return ChildrenIncrementButton;
        }

        public IWebElement GetCloseGuestPicker()
        {
            IWebElement FacilitiesOption = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'guestpicker__close')]/button")));
            return FacilitiesOption;
        }
        IWebElement FacilitiesOption = null;
        public IWebElement GetFacilitiesOption()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'filters')]//div[contains(@class, 'filters__group')]/button")));
            IList<IWebElement> lstSubFilters = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'filters')]//div[contains(@class, 'filters__group')]/button"));
            FacilitiesOption = lstSubFilters[3];
            return FacilitiesOption;
        }

        public IWebElement GetDiswasherFacility()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'filters__group')]//div[contains(@class, 'filters__group-item')]//input[@type ='checkbox']")));
            IList<IWebElement> lstFacility = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'filters__group')]//div[contains(@class, 'filters__group-item')]//input[@type ='checkbox']"));
            IWebElement DiswasherFacility = lstFacility[3];
            return DiswasherFacility;
        }

        public IWebElement GetPriceFilter()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'filters')]//div[contains(@class, 'filters__group')]/button")));
            IList<IWebElement> lstPriceFilters = webDriver.Current.FindElements(By.XPath("//div[contains(@class, 'filters')]//div[contains(@class, 'filters__group')]/button"));
            IWebElement PriceOption = lstPriceFilters[0];
            return PriceOption;
        }

        public IWebElement GetPriceSlider()
        {
            IWebElement PriceSlider = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'priceslider__slider')]//div[contains(@class, 'rc-slider-track')]")));
           
            return PriceSlider;
        }

        public IWebElement GetPriceSliderElement(bool low)
        {
            IWebElement PriceSliderElement = null;
            if (low)
            {
                 PriceSliderElement = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'priceslider__slider')]//div[contains(@class, 'rc-slider-handle-2')]")));
            }
            else
              {
                PriceSliderElement = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'priceslider__slider')]//div[contains(@class, 'rc-slider-handle-1')]")));
            }

                return PriceSliderElement;
        }

        public IWebElement GetCloseFacilities()
        {
            IWebElement FacilitiesOption = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'filters__close-button')]")));
            return FacilitiesOption;
        }


        public IWebElement GetSortingFilter()
        {
            //IWebElement SortingFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__sort')]//span[contains(@class, 'Select-arrow-zone')]/span")));
            //IWebElement SortingFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__sort')]//span[contains(@class, 'Select-value-label')]")));
            // IWebElement SortingFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__sort')]//div[contains(@class, 'Select')]/div[contains(@class, 'Select-control')]")));
            IWebElement SortingFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__sort')]//div[contains(@class, 'Select-value')]")));
            return SortingFilter;
        }

        public void WaitTillSortingFilterOpen()
        {
          wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@class, 'search-results__sort')]//div[contains(@role, 'combobox')][@aria-expanded='true']")));
            
        }

        public IWebElement GetDestinationFilterText()
        {
            IWebElement DestinationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form__destination-item-name')]")));
            return DestinationFilter;
        }

        public IWebElement GetSelectedFilter()
        {
            IWebElement SelectedFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'selected-facets')]//div[contains(@class, 'selected-facets__facet')]")));
            return SelectedFilter;
        }

        public List<IWebElement> GetSEOContent()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//section[contains(@class, 'breadcrumb')]//span[contains(@class, 'breadcrumb__lead')]")));
            List<IWebElement> SEOContent = webDriver.Current.FindElements(By.XPath("//section[contains(@class, 'breadcrumb')]//span[contains(@class, 'breadcrumb__lead')]")).ToList();
            return SEOContent;

                     
        }
         public List<IWebElement> GetTagClouds()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//section[contains(@class, 'tag-cloud__group')]")));
            List<IWebElement> TagClouds = webDriver.Current.FindElements(By.XPath("//section[contains(@class, 'tag-cloud__group')]//ul//li/a")).ToList();
            return TagClouds;
        }
    }
}
