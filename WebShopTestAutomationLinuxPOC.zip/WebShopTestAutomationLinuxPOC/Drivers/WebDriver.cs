﻿using System;
using System.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Edge;
using Microsoft.Extensions.Configuration;

namespace WebShopTestAutomation.Drivers
{
    public class WebDriver
    {
        private IWebDriver _currentWebDriver;
        private WebDriverWait _wait;

        public IWebDriver Current
        {
            get
            {
                if (_currentWebDriver == null)
                {
                    _currentWebDriver = GetWebDriver();
                }

                return _currentWebDriver;
            }
        }

        public WebDriverWait Wait
        {
            get
            {
                if (_wait == null)
                {
                    this._wait = new WebDriverWait(Current, TimeSpan.FromSeconds(10));
                }
                return _wait;
            }
        }

        private IWebDriver GetWebDriver()
        {
            switch (Environment.GetEnvironmentVariable("Test_Browser"))
            {
                case "IE":
                    return new InternetExplorerDriver(@"..\WebDriversSetup\IEDriver");
                //case "IE": return new InternetExplorerDriver(new InternetExplorerOptions(){IgnoreZoomLevel = true });
                case "Chrome": return new ChromeDriver(@"..\WebDriversSetup\ChromeDriver");
                case "Firefox": return new FirefoxDriver(@"..\WebDriversSetup\FirefoxDriver");

                default: return new ChromeDriver(@"..\WebDriversSetup\ChromeDriver");
            }
        }

        public void Quit()
        {
            _currentWebDriver?.Quit();
        }
    }
}
